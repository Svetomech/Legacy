﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Общие сведения об этой сборке предоставляются следующим набором 
' атрибутов. Отредактируйте значения этих атрибутов, чтобы изменить
' общие сведения об этой сборке.

' Проверьте значения атрибутов сборки

<Assembly: AssemblyTitle("Under the glass")> 
<Assembly: AssemblyDescription("freeware")> 
<Assembly: AssemblyCompany("Svetomech Inc")> 
<Assembly: AssemblyProduct("Under the glass")> 
<Assembly: AssemblyCopyright("Copyright © Svetomech 2014")> 
<Assembly: AssemblyTrademark("SvtInc_Utg")> 

<Assembly: ComVisible(False)>

'Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
<Assembly: Guid("d4108e37-d020-4961-891b-246976ba4cca")> 

' Сведения о версии сборки состоят из следующих четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'      Номер построения
'      Редакция
'
' Можно задать все значения или принять номер построения и номер редакции по умолчанию, 
' используя "*", как показано ниже:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.2.1.0")> 
<Assembly: AssemblyFileVersion("2.2.1.0")> 
